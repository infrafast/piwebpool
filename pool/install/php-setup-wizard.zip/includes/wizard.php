<?php

/**
* PHP Setup Wizard class
*/
class phpSetupWizard extends phpSetupWizard_Core
{
}
