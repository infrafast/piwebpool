$(function(){
	$("#location").geocomplete();

	$('#location').on('keyup change',function(e){
	  	if(e.which == 13 || e.type == 'change'){
	  		history.pushState("", document.title, window.location.pathname);
	  		var address = $(this).val();
	  		var geocoder = new google.maps.Geocoder();

	        geocoder.geocode( { 'address': address}, function(results, status) {
	        	console.log(results);
	            if (status == google.maps.GeocoderStatus.OK) {
		            var latitude = results[0].geometry.location.lat();
		            var longitude = results[0].geometry.location.lng();
		            weatherForecast(latitude,longitude);
	            } 
	        }); 
	  	}
	});

	function weatherForecast(lat,lon){
		var requestUrl = 'process.php'
		$.get(requestUrl,{latitude:lat,longitude:lon},function(response,status){
			if(status === 'success'){
				console.log(response);
				$('#loader').html(response);
				window.location.hash = 'slide-1';
			}
		});
	} 
});