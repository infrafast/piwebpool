<?php
$latitude = $_GET['latitude'];
$longitude = $_GET['longitude'];
$endpoint = 'https://api.forecast.io/forecast/YOUR_API_KEY/'.$latitude.','.$longitude;
$result = file_get_contents($endpoint);
$data = json_decode($result);

$icons = [
	'clear-day' => 'wi-day-sunny',
	'clear-night' => 'wi-night-clear',
	'rain'=>'wi-rain',
	'snow'=>'wi-snow',
	'sleet'=>'wi-leet',
	'wind'=>'wi-windy',
	'fog'=>'wi-fog',
	'cloudy'=>'wi-cloudy',
	'partly-cloudy-day'=>'wi-day-cloudy',
	'partly-cloudy-night'=>'wi-night-cloudy'
];

$weather = [
	'clear-day' => 'sunny',
	'clear-night' => 'sunny',
	'rain'=>'rain',
	'snow'=>'rain',
	'sleet'=>'storm',
	'wind'=>'sunny',
	'fog'=>'drizzle',
	'cloudy'=>'drizzle',
	'partly-cloudy-day'=>'drizzle',
	'partly-cloudy-night'=>'drizzle'
];

$today = $data->currently;
$temp = ($today->temperature -32) / 1.8;

$html = '<div class="slide" id="slide-1" data-weather="'.$weather[$today->icon].'">
			<div class="slide__element slide__element--date">'.date("l, j",$today->time).'<sup>'.date("S",$today->time).'</sup> of '.date("F Y",$today->time).'</div>
			<div class="slide__element slide__element--temp">'.round($temp).'°<small>C</small></div>
		</div>';

$i = 2;
foreach($data->daily->data as $day){
	$temp = ($day->temperatureMax -32) / 1.8;
	$html .= '<div class="slide" id="slide-'.$i.'" data-weather="'.$weather[$day->icon].'">
				<div class="slide__element slide__element--date">'.date("l, j",$day->time).'<sup>'.date("S",$day->time).'</sup> of '.date("F Y",$day->time).'</div>
				<div class="slide__element slide__element--temp">'.round($temp).'°<small>C</small></div>
			</div>';
	$i++;
}

$j= 2;
$html .= '<nav class="slideshow__nav">
				<a class="nav-item" href="#slide-1"><i class="icon wi '.$icons[$today->icon].'"></i><span>'.date("n/j",$today->time).'</span></a>';
foreach($data->daily->data as $day){
	$html .= '<a class="nav-item" href="#slide-'.$j.'"><i class="icon wi '.$icons[$day->icon].'"></i><span>'.date("n/j",$day->time).'</span></a>';
	$j++;
}

$html .= '</nav>';

echo $html;
?>